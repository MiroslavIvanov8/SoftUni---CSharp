﻿using System.Net;

namespace PokemonTrainer
{
    public class Program
    {
        static void Main()
        {
            Dictionary<string,List<Pokemon>> trainerPokemonts = new Dictionary<string,List<Pokemon>>();
            Dictionary<string,Trainer> trainers = new ();
            string command;
            while((command = Console.ReadLine())!="Tournament")
            {
                // "{trainerName} {pokemonName} {pokemonElement} {pokemonHealth}"
                string[] info = command.Split(" ", StringSplitOptions.RemoveEmptyEntries);

                string trainerName = info[0];
                string pokemonName = info[1];
                string pokemonElemnt = info[2];
                int pokemonHealth = int.Parse(info[3]);
                Trainer trainer = new Trainer
                {
                    Name = trainerName,
                    Badges = 0,
                    PokemonCollection = new List<Pokemon>(),
                };
                Pokemon pokemon = new Pokemon
                {
                    Name= pokemonName,
                    Element = pokemonElemnt,
                    Health= pokemonHealth,
                };

                trainer.PokemonCollection.Add(pokemon);

                if (!trainerPokemonts.ContainsKey(trainerName))
                {
                    trainerPokemonts.Add(trainerName, new List<Pokemon>());
                }
                trainerPokemonts[trainerName].Add(pokemon);

                if (!trainers.ContainsKey(trainerName))
                {
                    trainers.Add(trainerName, trainer);
                }
                else
                trainers[trainerName].PokemonCollection.Add(pokemon);
            }

            string nextCommand;
            while ((nextCommand = Console.ReadLine()) != "End")
            {
                string type = nextCommand;

                foreach(var trainer in trainerPokemonts)
                {
                    bool hasType = false;
                    foreach(var pokemon in trainer.Value)
                    {
                        if (pokemon.Element == type)
                        {
                            trainers[trainer.Key].Badges++; 
                            hasType = true;
                        }
                    }
                    if (!hasType)
                    {
                        foreach (var pokemon in trainer.Value)
                        {                            
                            pokemon.Health -= 10;
                            if(pokemon.Health<=0)
                            trainers[trainer.Key].PokemonCollection.Remove(pokemon);
                        }
                           
                    }
                }
            }

            foreach(var trainer in trainers.OrderByDescending(t=>t.Value.Badges))
            {
                Console.WriteLine($"{trainer.Key} {trainer.Value.Badges} {trainer.Value.PokemonCollection.Count}");
            }
        }
    }
}