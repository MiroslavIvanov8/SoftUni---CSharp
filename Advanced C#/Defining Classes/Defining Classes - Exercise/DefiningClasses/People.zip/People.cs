﻿namespace DefiningClasses
{
    internal class People
    {
    }
}