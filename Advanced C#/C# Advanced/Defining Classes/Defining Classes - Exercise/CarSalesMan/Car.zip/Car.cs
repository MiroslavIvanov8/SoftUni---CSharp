﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarSalesMan
{
    public class Car
    {
        public string Model { get; set; }
        public Engine Engine { get; set; }
        public int Weigth { get; set; } // optional
        public string Color { get; set; } // optional


    }
}
