﻿using System.Security.Cryptography.X509Certificates;

namespace MathOperations
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
            MathOperations mo = new MathOperations();
            Console.WriteLine(mo.Add(1,2));
            Console.WriteLine(mo.Add(2.2, 3.3, 5.5));
            Console.WriteLine(mo.Add(2.2m, 3.3m, 4.4m));


        }

        public class MathOperations
        {
            public int Add(int a, int b) => a+ b;

            public double Add(double a, double b, double c) => a + b + c;
            
            public decimal Add(decimal a, decimal b, decimal c) => a + b + c;
        }
        

    }
}